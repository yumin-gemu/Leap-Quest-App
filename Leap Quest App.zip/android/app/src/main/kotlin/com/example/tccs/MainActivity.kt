package com.example.tccs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
